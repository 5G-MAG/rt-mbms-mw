To compile repair_sender flutelib has to be compiled without USE_HTTP_REPAIR.
